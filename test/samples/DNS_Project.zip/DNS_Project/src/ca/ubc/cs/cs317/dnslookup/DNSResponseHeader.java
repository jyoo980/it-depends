package ca.ubc.cs.cs317.dnslookup;

public class DNSResponseHeader {

  short questions;
  short answerRRs;
  short authorityRRs;
  short additionalRRs;
  boolean nameError;
  boolean authoritative;

  public DNSResponseHeader(short questions, short answerCount, short authorityCount, short additionalCount, boolean nameError, boolean authoritative) {
    this.questions = questions;
    this.answerRRs = answerCount;
    this.authorityRRs = authorityCount;
    this.additionalRRs = additionalCount;
    this.nameError = nameError;
    this.authoritative = authoritative;
  }

}
