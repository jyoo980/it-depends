package ca.ubc.cs.cs317.dnslookup;

import java.io.Console;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.ByteBuffer;

public class DNSLookupService {

    private static final int DEFAULT_DNS_PORT = 53;
    private static final int MAX_INDIRECTION_LEVEL = 10;

    private static InetAddress rootServer;
    private static boolean verboseTracing = false;
    private static DatagramSocket socket;

    private static DNSCache cache = DNSCache.getInstance();

    private static Random random = new Random();

    static String queryMessage;
    static int offset;
    static int indirectionLevel;
    static DNSNode initialNode;
    static DNSNode currNode;

    /**
     * Main function, called when program is first invoked.
     *
     * @param args list of arguments specified in the command line.
     */
    public static void main(String[] args) {

        if (args.length != 1) {
            System.err.println("Invalid call. Usage:");
            System.err.println("\tjava -jar DNSLookupService.jar rootServer");
            System.err.println("where rootServer is the IP address (in dotted form) of the root DNS server to start the search at.");
            System.exit(1);
        }

        try {
            rootServer = InetAddress.getByName(args[0]);
            System.out.println("Root DNS server is: " + rootServer.getHostAddress());
        } catch (UnknownHostException e) {
            System.err.println("Invalid root server (" + e.getMessage() + ").");
            System.exit(1);
        }

        try {
            socket = new DatagramSocket();
            socket.setSoTimeout(5000);
        } catch (SocketException ex) {
            ex.printStackTrace();
            System.exit(1);
        }

        Scanner in = new Scanner(System.in);
        Console console = System.console();
        do {
            // Use console if one is available, or standard input if not.
            String commandLine;
            if (console != null) {
                System.out.print("DNSLOOKUP> ");
                commandLine = console.readLine();
            } else
                try {
                    commandLine = in.nextLine();
                } catch (NoSuchElementException ex) {
                    break;
                }
            // If reached end-of-file, leave
            if (commandLine == null) break;

            // Ignore leading/trailing spaces and anything beyond a comment character
            commandLine = commandLine.trim().split("#", 2)[0];

            // If no command shown, skip to next command
            if (commandLine.trim().isEmpty()) continue;

            String[] commandArgs = commandLine.split(" ");

            if (commandArgs[0].equalsIgnoreCase("quit") ||
                    commandArgs[0].equalsIgnoreCase("exit"))
                break;
            else if (commandArgs[0].equalsIgnoreCase("server")) {
                // SERVER: Change root nameserver
                if (commandArgs.length == 2) {
                    try {
                        rootServer = InetAddress.getByName(commandArgs[1]);
                        System.out.println("Root DNS server is now: " + rootServer.getHostAddress());
                    } catch (UnknownHostException e) {
                        System.out.println("Invalid root server (" + e.getMessage() + ").");
                        continue;
                    }
                } else {
                    System.out.println("Invalid call. Format:\n\tserver IP");
                    continue;
                }
            } else if (commandArgs[0].equalsIgnoreCase("trace")) {
                // TRACE: Turn trace setting on or off
                if (commandArgs.length == 2) {
                    if (commandArgs[1].equalsIgnoreCase("on"))
                        verboseTracing = true;
                    else if (commandArgs[1].equalsIgnoreCase("off"))
                        verboseTracing = false;
                    else {
                        System.err.println("Invalid call. Format:\n\ttrace on|off");
                        continue;
                    }
                    System.out.println("Verbose tracing is now: " + (verboseTracing ? "ON" : "OFF"));
                } else {
                    System.err.println("Invalid call. Format:\n\ttrace on|off");
                    continue;
                }
            } else if (commandArgs[0].equalsIgnoreCase("lookup") ||
                    commandArgs[0].equalsIgnoreCase("l")) {
                // LOOKUP: Find and print all results associated to a name.
                RecordType type;
                if (commandArgs.length == 2)
                    type = RecordType.A;
                else if (commandArgs.length == 3)
                    try {
                        type = RecordType.valueOf(commandArgs[2].toUpperCase());
                    } catch (IllegalArgumentException ex) {
                        System.err.println("Invalid query type. Must be one of:\n\tA, AAAA, NS, MX, CNAME");
                        continue;
                    }
                else {
                    System.err.println("Invalid call. Format:\n\tlookup hostName [type]");
                    continue;
                }
                findAndPrintResults(commandArgs[1], type);
            } else if (commandArgs[0].equalsIgnoreCase("dump")) {
                // DUMP: Print all results still cached
                cache.forEachNode(DNSLookupService::printResults);
            } else {
                System.err.println("Invalid command. Valid commands are:");
                System.err.println("\tlookup fqdn [type]");
                System.err.println("\ttrace on|off");
                System.err.println("\tserver IP");
                System.err.println("\tdump");
                System.err.println("\tquit");
                continue;
            }

        } while (true);

        socket.close();
        System.out.println("Goodbye!");
    }

    /**
     * Finds all results for a host name and type and prints them on the standard output.
     *
     * @param hostName Fully qualified domain name of the host being searched.
     * @param type     Record type for search.
     */
    private static void findAndPrintResults(String hostName, RecordType type) {

        initialNode = new DNSNode(hostName, type);
        indirectionLevel = 0;
        printResults(initialNode, getResults(initialNode, 0));
    }

    /**
     * Finds all the result for a specific node.
     *
     * @param node             Host and record type to be used for search.
     * @param indirectionLevel Control to limit the number of recursive calls due to CNAME redirection.
     *                         The initial call should be made with 0 (zero), while recursive calls for
     *                         regarding CNAME results should increment this value by 1. Once this value
     *                         reaches MAX_INDIRECTION_LEVEL, the function prints an error message and
     *                         returns an empty set.
     * @return A set of resource records corresponding to the specific query requested.
     */
    private static Set<ResourceRecord> getResults(DNSNode node, int indirectionLevel) {
        // TODO To be completed by the student
        if (indirectionLevel > MAX_INDIRECTION_LEVEL) {
            System.err.println("Maximum number of indirection levels reached.");
            return Collections.emptySet();
        }

        currNode = node;

        if (cache.getCachedResults(node).size() == 0) { // If not in our cache, start searching
          retrieveResultsFromServer(node, rootServer);
        }

        return cache.getCachedResults(node);
    }

    /**
     * Retrieves DNS results from a specified DNS server. Queries are sent in iterative mode,
     * and the query is repeated with a new server if the provided one is non-authoritative.
     * Results are stored in the cache.
     *
     * @param node   Host name and record type to be used for the query.
     * @param server Address of the server to be used for the query.
     */
    private static void retrieveResultsFromServer(DNSNode node, InetAddress server) {
      // TODO To be completed by the student
      try {
        if (verboseTracing) {
          System.out.print("\n\n");
        }

        // Set-up query
        String domain = node.getHostName();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = createQueryStream(baos, node, server);

        // Send DNS Request Frame
        byte[] dnsFrame = baos.toByteArray();
        socket = new DatagramSocket();
        DatagramPacket dnsReqPacket = new DatagramPacket(dnsFrame, dnsFrame.length, server, 53);
        socket.send(dnsReqPacket);
        socket.setSoTimeout(5000);

        try { // Parse DNS Response for the first time
          parseDNSResponse(node);
        } catch (SocketTimeoutException e) { // It timed out, let's try again
          if (verboseTracing) {
            System.out.print("\n\n");
            System.out.println(queryMessage);   // Resend the DNS query
          }
          socket.send(dnsReqPacket); // If this times out, it will go to the catch block at the end and stop querying
          socket.setSoTimeout(5000);
          parseDNSResponse(node);
        }
      } catch (Exception e) {
        // Do nothing, error return resource record will be printed
      }
    }

    private static void parseDNSResponse(DNSNode node) throws SocketTimeoutException, IOException, UnknownHostException {
      // Receive DNS Response Frame from DNS server
      byte[] buf = new byte[1024];
      DatagramPacket dnsResponsePacket = new DatagramPacket(buf, buf.length);
      socket.receive(dnsResponsePacket);

      // Parse through response
      DNSResponseHeader header = extractHeaderFromDNSResponse(buf);
      extractQuestionsFromDNSResponse(buf, (int) header.questions);
      List<ResourceRecord> listAnswerRRs = extractAnswersFromDNSResponse(buf, (int) header.answerRRs);
      List<String> listNameServers = extractNameServersFromDNSResponse(buf, (int) header.authorityRRs);
      Map<String, InetAddress> mapAdditionalRRs = extractAdditionalRRsFromDNSResponse(buf, (int) header.additionalRRs);
      socket.close();

      // Handle different response cases
      // Case 1: No answers found and no error
      if (header.answerRRs == 0 && !header.nameError) {   // If no answers were found and no error in the response
        if (header.authoritative) {                       // If no answers found, no error but it is an authoritative response for our query
          return;
        }
        boolean doesNameServerHaveAddress = false;        // Check if we have an IP address for one of the name servers in the response
        for (String nameServer : listNameServers) {
          if (mapAdditionalRRs.get(nameServer) != null) {
            InetAddress nextAddr = mapAdditionalRRs.get(nameServer);
            retrieveResultsFromServer(node, nextAddr);    // Query it for the domain name to be resolved
            doesNameServerHaveAddress = true;
            break;
          }
        }
        // If no IP address for name server provided
        if (!doesNameServerHaveAddress && listNameServers.size() != 0) {
          DNSNode nameServerNode = new DNSNode(listNameServers.get(0), RecordType.getByCode(1));  // Make a query for the first name server found
          Set<ResourceRecord> nameServerQueryResults = getResults(nameServerNode, 0);

          for (ResourceRecord nameServerResult : nameServerQueryResults) {
            InetAddress nameServerAddress = nameServerResult.getInetResult();
            currNode = initialNode;                                                               // Reset our current node to the initial node
            retrieveResultsFromServer(node, nameServerAddress);                                   // Continue the current query with our newly resolved name server address
          }
        }
      }
      // Case 2: Answer(s) found
      else if (header.answerRRs != 0 && !header.nameError) {                // If answer(s) found
        if (cache.getCachedResults(currNode).size() == 0) {                 // If answer found doesn't match our current query
          for (ResourceRecord answer : listAnswerRRs) {                     // Check for CNAMEs we can query
            if (answer.getHostName().equals(currNode.getHostName()) &&
                answer.getType().getCode() == 5) {                          // If a CNAME to our initial host is found
              DNSNode cnameNode = new DNSNode(answer.getTextResult(), currNode.getType());
              DNSNode previousNode = currNode;
              Set<ResourceRecord> cnameQueryResults = getResults(cnameNode, indirectionLevel + 1);
              currNode = previousNode;                                      // Reset our current query

              for (ResourceRecord cnameQueryResult : cnameQueryResults) {
                cache.addResult(new ResourceRecord(currNode.getHostName(), currNode.getType(), cnameQueryResult.getTTL(), cnameQueryResult.getInetResult()));
              }
              break;
            }
          }
        }
      }
    }

    private static void verbosePrintResourceRecord(ResourceRecord record, int rtype) {
        if (verboseTracing)
            System.out.format("       %-30s %-10d %-4s %s\n", record.getHostName(),
                    record.getTTL(),
                    record.getType() == RecordType.OTHER ? rtype : record.getType(),
                    record.getTextResult());
    }

    /**
     * Prints the result of a DNS query.
     *
     * @param node    Host name and record type used for the query.
     * @param results Set of results to be printed for the node.
     */
    private static void printResults(DNSNode node, Set<ResourceRecord> results) {
        if (results.isEmpty()) {
            System.out.printf("%-30s %-5s %-8d %s\n", node.getHostName(),
                    node.getType(), -1, "0.0.0.0");
        }
        for (ResourceRecord record : results) {
            System.out.printf("%-30s %-5s %-8d %s\n", node.getHostName(),
                    node.getType(), record.getTTL(), record.getTextResult());
        }
    }

    // -- Student Helper Method --
    // Helper function to build DNS queries
    private static DataOutputStream createQueryStream(ByteArrayOutputStream baos, DNSNode node, InetAddress server) throws IOException, UnsupportedEncodingException {
      DataOutputStream dos = new DataOutputStream(baos);

      String domain = node.getHostName();
      int code = node.getType().getCode();
      // Identifier
      int identifier = random.nextInt(65536);
      short shortIdentifier = (short) (identifier & 0x00FFFF);
      dos.writeShort(shortIdentifier);
      if (verboseTracing) {
        queryMessage = "Query ID     " + identifier + " " + domain + "  " + RecordType.getByCode(code) + " --> " + server;
        System.out.println(queryMessage);
        //System.out.println("Query ID     " + identifier + " " + domain + "  " + RecordType.getByCode(code) + " --> " + server);
      }

      // 1 bit flag indicating query and no error
      dos.writeShort(0x0000);

      // Query count: number of questions in the question section of the message
      dos.writeShort(0x0001);

      // Answer count: number of resource records in the Answer section of the message
      dos.writeShort(0x0000);

      // Name server records: number of recourse records in the Authority section of the message
      dos.writeShort(0x0000);

      // Additional record count: specifies number of recourse records in additional section of the message
      dos.writeShort(0x0000);

      // Write hostname to be resolved into datagram
      String[] domainParts = domain.split("\\.");
      for (int i = 0; i < domainParts.length; i++) {
          byte[] domainBytes = domainParts[i].getBytes("UTF-8");
          dos.writeByte(domainBytes.length);  // length of a label
          dos.write(domainBytes);             // the actual label
      }

      // End of the QNAME
      dos.writeByte(0x00);

      // QTYPE - Type 0x01 = A host request
      //dos.writeShort(0x0001);
      dos.writeShort((short) code);

      // QCLASS - Class 0x01 = IN
      dos.writeShort(0x0001);

      return dos;
    }

    // -- Student Helper Method --
    // Parse through the header info from DNS response
    private static DNSResponseHeader extractHeaderFromDNSResponse(byte[] buf) {
      // Extract info from DNS Response
      offset = 0;
      short ID = (short)(((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
      int intID = ID & 0xFFFF;
      offset += 2;
      short flags = (short)(((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
      boolean authoritative = false;
      boolean nameError = false;
      if ((flags & 0x0400) == 0x0400) { // check if authoritative
        authoritative = true;
      }
      if ((flags & 0x000F) == 0x0003 || (flags & 0x000F) == 0x0005) { // check if RCODE = 3 or 5
        nameError = true;
      }
      offset += 2;
      if (verboseTracing) {
        System.out.println("Response ID: " + intID + " Authoritative = " + authoritative);
      }
      short questions = (short)(((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
      offset += 2;
      short answerRRs = (short)(((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
      offset +=2;
      short authorityRRs = (short)(((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
      offset +=2;
      short additionalRRs = (short)(((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
      offset +=2;
      DNSResponseHeader header = new DNSResponseHeader(questions, answerRRs, authorityRRs, additionalRRs, nameError, authoritative);
      return header;
    }

    // -- Student Helper Method --
    // Parse through DNS response questions
    private static void extractQuestionsFromDNSResponse(byte[] buf, int questions) {
      // Extracting Questions
      for (int j = 0; j < questions; j++) {
        String qName = getNameFromBuffer(buf);
        qName = qName.substring(0, qName.length() - 1);

        StringBuilder qType = new StringBuilder();
        qType.append("0x");
        qType.append(String.format("%02x", buf[offset]));
        qType.append(String.format("%02x", buf[offset + 1]));
        offset += 2;
        StringBuilder qClass = new StringBuilder();
        qClass.append("0x");
        qClass.append(String.format("%02x", buf[offset]));
        qClass.append(String.format("%02x", buf[offset + 1]));
        offset += 2;
      }
    }

    // -- Student Helper Method --
    // Parse DNS Response for answers
    private static List<ResourceRecord> extractAnswersFromDNSResponse(byte[] buf, int answers) throws UnknownHostException {
      if (verboseTracing) {
        System.out.println("  Answers (" + answers + ")");
      }
      // Extracting answerRRs
      List<ResourceRecord> listAnswerRRs = new ArrayList<>();
      for (int m = 0; m < answers; m++) {
        // Get the aName
        short aName = (short)((buf[offset] <<8) + (buf[offset + 1]));
        String strAName = "";
        strAName = getNameFromBuffer(buf);
        strAName = strAName.substring(0, strAName.length() - 1);

        // Get the aType
        short aType = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get the aClass
        short aClass = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get the ttl
        byte[] bufTTL = new byte[4];
        bufTTL[0] = buf[offset];
        bufTTL[1] = buf[offset + 1];
        bufTTL[2] = buf[offset + 2];
        bufTTL[3] = buf[offset + 3];
        int aTTL = ByteBuffer.wrap(bufTTL).getInt();
        offset += 4;

        // Get the aDataLen
        short aDataLen = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get the Address
        String aData = "";
        ResourceRecord aResourceRecord = null;
        if (aType == 1) { // if type is A
          int addr1 = buf[offset] & 0xFF;
          int addr2 = buf[offset + 1] & 0xFF;
          int addr3 = buf[offset + 2] & 0xFF;
          int addr4 = buf[offset + 3] & 0xFF;
          aData = addr1 + "." + addr2 + "." + addr3 + "." + addr4;
          offset += 4;
          aResourceRecord = new ResourceRecord(strAName,
                                                RecordType.getByCode(aType),
                                                Long.valueOf(aTTL),
                                                InetAddress.getByName(aData));
        } else if (aType == 5) { // if type is CNAME
          aData = getNameFromBuffer(buf);
          aData = aData.substring(0, aData.length() - 1);
          aResourceRecord = new ResourceRecord(strAName,
                                                RecordType.getByCode(aType),
                                                Long.valueOf(aTTL),
                                                aData);
        } else if (aType == 28) {
          for (int i = 0; i < 8; i++) {
            short currAddrVal = (short) (((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
            aData = aData + String.format("%04x", currAddrVal) + ":";
            offset += 2;
          }
          aData = aData.substring(0, aData.length() - 1); // remove trailing :
          aResourceRecord = new ResourceRecord(strAName,
                                                RecordType.getByCode(aType),
                                                Long.valueOf(aTTL),
                                                InetAddress.getByName(aData));
        }

        verbosePrintResourceRecord(aResourceRecord, aType);
        listAnswerRRs.add(aResourceRecord);

        cache.addResult(aResourceRecord);
      }
      return listAnswerRRs;
    }

    // -- Student Helper Method --
    // Parse DNS Response for name servers
    private static List<String> extractNameServersFromDNSResponse(byte[] buf, int nameservers) {
      if (verboseTracing) {
        System.out.println("  Nameservers (" + nameservers + ")");
      }
      List<String> listNameServers = new LinkedList<>();
      // Extracting Nameservers
      for (int k = 0; k < nameservers; k++) {
        // Get the nsName
        short nsName = (short)((buf[offset] <<8) + (buf[offset + 1]));
        //offset +=2;
        String strNsName = "";
        strNsName = getNameFromBuffer(buf);
        strNsName = strNsName.substring(0, strNsName.length() - 1);

        // Get the nsType
        short nsType = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get the nsClass
        short nsClass = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get the ttl
        byte[] bufTTL = new byte[4];
        bufTTL[0] = buf[offset];
        bufTTL[1] = buf[offset + 1];
        bufTTL[2] = buf[offset + 2];
        bufTTL[3] = buf[offset + 3];
        int nsTTL = ByteBuffer.wrap(bufTTL).getInt();
        offset += 4;

        // Get the nsDataLen
        short nsDataLen = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get ns
        String nameServer = getNameFromBuffer(buf);
        nameServer = nameServer.substring(0, nameServer.length() - 1);
        listNameServers.add(nameServer);

        ResourceRecord nsResourceRecord = new ResourceRecord(strNsName,
                                                              RecordType.getByCode(nsType),
                                                              Long.valueOf(nsTTL),
                                                              nameServer);

        verbosePrintResourceRecord(nsResourceRecord, nsType);

        cache.addResult(nsResourceRecord);
      }
      return listNameServers;
    }

    // -- Student Helper Method --
    // Parse DNS response for Additional RRs
    private static Map<String, InetAddress> extractAdditionalRRsFromDNSResponse(byte[] buf, int additionalRRs) throws UnknownHostException {
      // Extracting additional information
      if (verboseTracing) {
        System.out.println("  Additional Information (" + additionalRRs + ")");
      }

      Map<String, InetAddress> mapAddInformation = new HashMap<>();
      for (int l = 0; l < additionalRRs; l++) {
        // Get the nsName
        short arName = (short)(((buf[offset] & 0xFF) <<8) + (buf[offset + 1] & 0xFF));
        String strArName = "";
        strArName = getNameFromBuffer(buf);
        strArName = strArName.substring(0, strArName.length() - 1);

        // Get the nsType
        short arType = (short)((buf[offset] <<8) + (buf[offset + 1]));
        String strArType = "";
        if (arType == 1) {
          strArType = "A";
        } else if (arType == 2) {
          strArType = "NS";
        } else if (arType == 28) {
          strArType = "AAAA";
        }
        offset += 2;

        // Get the nsClass
        short arClass = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get the ttl
        byte[] bufTTL = new byte[4];
        bufTTL[0] = buf[offset];
        bufTTL[1] = buf[offset + 1];
        bufTTL[2] = buf[offset + 2];
        bufTTL[3] = buf[offset + 3];
        int arTTL = ByteBuffer.wrap(bufTTL).getInt();
        offset += 4;

        // Get the nsDataLen
        short arDataLen = (short)((buf[offset] <<8) + (buf[offset + 1]));
        offset += 2;

        // Get Address
        String arAddr = "";
        if (strArType.equals("A")) {
          int addr1 = buf[offset] & 0xFF;
          int addr2 = buf[offset + 1] & 0xFF;
          int addr3 = buf[offset + 2] & 0xFF;
          int addr4 = buf[offset + 3] & 0xFF;
          arAddr = addr1 + "." + addr2 + "." + addr3 + "." + addr4;
          offset += 4;
        } else if (strArType.equals("AAAA")) {
          for (int i = 0; i < 8; i++) {
            short currAddrVal = (short) (((buf[offset] & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
            arAddr = arAddr + String.format("%04x", currAddrVal) + ":";
            offset += 2;
          }
          arAddr = arAddr.substring(0, arAddr.length() - 1); // remove trailing :
        }

        if (strArType.equals("A")) { // If this has an IPv4 address
          mapAddInformation.put(strArName, InetAddress.getByName(arAddr));
        }

        ResourceRecord arResourceRecord = new ResourceRecord(strArName,
                                                              RecordType.getByCode(arType),
                                                              Long.valueOf(arTTL),
                                                              InetAddress.getByName(arAddr));

        verbosePrintResourceRecord(arResourceRecord, arType);

        cache.addResult(arResourceRecord);
      }
      return mapAddInformation;
    }

    // -- Student Helper Method --
    // Get name from buffer
    // If a pointer is encountered, call pointer helper
    private static String getNameFromBuffer(byte[] buf) {
      String name = "";
      int len = buf[offset];

      if (len == 0) {
        offset += 1;
        return name;
      }

      if ((len & 0xc0) == 0xc0) { // if it is a pointer
        short s = (short)(((len & 0xFF) << 8) + (buf[offset + 1] & 0xFF));
        short ptrOffset = (short) (s & 0x3FFF);

        name += getNameFromPointerInBuffer(buf, ptrOffset);
        offset += 2;
      } else { // if not a pointer
        offset += 1;
        for (int i = 1; i <= len; i++) {
          name += (char) (buf[offset] & 0xFF);
          offset += 1;
        }
        name += ".";
        name += getNameFromBuffer(buf);
      }

      return name;
    }

    // -- Student Helper Method --
    // Get the name or data from a pointer in the buffer
    // If it points to another pointer, make a recursive call to that location
    // Else simply get the data
    private static String getNameFromPointerInBuffer(byte[] buf, int ptrOffset) {
      String name = "";
      int len = buf[ptrOffset];

      if (len == 0) {
        return name;
      }

      if ((len & 0xc0) == 0xc0) { // if it is a pointer
        short s = (short)(((len & 0xFF) << 8) + (buf[ptrOffset + 1] & 0xFF));
        short newPtrOffset = (short) (s & 0x3FFF);

        name += getNameFromPointerInBuffer(buf, newPtrOffset);
      } else {
        for (int i = 1; i <= len; i++) {
          name += (char) (buf[ptrOffset + i] & 0xFF);
        }
        name += ".";
        name += getNameFromPointerInBuffer(buf, ptrOffset + len + 1);
      }

      return name;
    }
}
